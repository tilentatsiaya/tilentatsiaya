import requests
from bs4 import BeautifulSoup
import pandas as pd
import time

BASE_URL = 'https://www.jumia.co.ke'
CATEGORY_URL = 'https://www.jumia.co.ke/facial-skin-care-d/'
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
}

data = []

response = requests.get(CATEGORY_URL, headers=HEADERS)
soup = BeautifulSoup(response.text, 'html.parser')

# Find product links
product_links = []
for a in soup.select('a.core'):
    href = a.get('href')
    if href and href not in product_links:
        product_links.append(BASE_URL + href)
    if len(product_links) >= 15:
        break

for link in product_links[:10]:
    prod_resp = requests.get(link, headers=HEADERS)
    prod_soup = BeautifulSoup(prod_resp.text, 'html.parser')
    
    # Extract fields
    try:
        name = prod_soup.find('h1', {'class': '-fs20 -pts -pbxs'}).text.strip()
    except:
        name = ''
    try:
        brand = prod_soup.find('a', {'class': '-plxs -pvxs'}).text.strip()
    except:
        brand = ''
    try:
        price = prod_soup.find('span', {'class': '-b -ltr -tal -fs24'}).text.strip()
    except:
        price = ''
    try:
        desc = prod_soup.find('div', {'class': 'markup -mhm -pvl -oxa -sc'}).text.strip()
    except:
        desc = ''
    try:
        image = prod_soup.find('img', {'class': 'img'})['data-src']
    except:
        image = ''
    # Ingredients and other fields may not be available
    ingredients = ''
    size = ''
    barcode = ''
    skin_concern = ''
    age = ''
    series = ''
    
    data.append({
        'Brand Name': brand,
        'Product Name': name,
        'Product Description': desc,
        'Image URL': image,
        'Price': price,
        'Size': size,
        'Ingredients': ingredients,
        'Barcode': barcode,
        'Skin Concern': skin_concern,
        'Age': age,
        'Series': series,
        'Source URL': link
    })
    time.sleep(1)

pd.DataFrame(data).to_csv('skincare_products.csv', index=False)
print('Jumia scraping complete. Data saved to skincare_products.csv.')
