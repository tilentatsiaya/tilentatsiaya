# Skincare Product Web Scraping & Ingredient Grouping Task

## Overview
This project demonstrates web scraping and ingredient-based grouping for skincare products, as required by the Veeffyed interview assignment.

## Workflow

1. **Scraping Products from Jumia**
   - The script `jumia_scraper.py` scrapes at least 10 facial skincare products from [Jumia Kenya - Facial Skin Care](https://www.jumia.co.ke/facial-skin-care-d/).
   - Extracted fields include: Brand Name, Product Name, Product Description, Image URL, Price, and Source URL. Some fields (Ingredients, Size, Barcode, etc.) may be empty if not available on the site.
   - Output: `skincare_products.csv`

2. **Extracting Ingredients & Grouping Products**
   - The script `ingredient_grouping.py` processes `skincare_products.csv` to extract likely ingredients from the product descriptions using regex and a list of common cosmetic ingredients.
   - It populates the Ingredients column and groups products that share at least 2 ingredients.
   - Outputs:
     - `skincare_products_with_ingredients.csv`: Cleaned data with extracted ingredients.
     - `ingredient_groups.csv`: Table of product groups sharing key ingredients.

## Requirements

- Python 3
- Required packages:
  - requests
  - beautifulsoup4
  - pandas

You can install all required packages at once using:

```
pip install -r requirements.txt
```

The `time` module is used in the scripts but is part of the Python standard library and does not require installation.

## How to Use

1. **Run the Scraper**
   - Run: `python jumia_scraper.py`
   - This will create `skincare_products.csv`.

2. **Extract Ingredients and Group**
   - Run: `python ingredient_grouping.py`
   - This will create `skincare_products_with_ingredients.csv` and `ingredient_groups.csv`.

3. **View the CSV Files**
   - For best readability, open the CSV files in Excel or Google Sheets.
   - The cleaned CSV (`skincare_products_with_ingredients.csv`) will have a more structured Ingredients column.

## Notes & Limitations
- Some fields may be empty due to limitations of the source website (Jumia does not always provide structured ingredient lists, barcodes, etc.).
- Ingredients are extracted using keyword matching and regex from the product description, so may not be exhaustive or perfectly accurate.
- Grouping is based on products sharing at least 2 ingredients.

## Deliverables
- `skincare_products.csv` — Raw scraped data
- `skincare_products_with_ingredients.csv` — Cleaned data with extracted ingredients
- `ingredient_groups.csv` — Grouped ingredient match table
- `jumia_scraper.py` — Scraping script
- `ingredient_grouping.py` — Ingredient extraction and grouping script
- `README.md` — This documentation file

---

For any issues or questions, please refer to the code comments or contact the author.
