import pandas as pd
import re
from collections import defaultdict

# Load the scraped data
csv_path = 'skincare_products.csv'
df = pd.read_csv(csv_path)

# Define a set of common cosmetic ingredient keywords for extraction
COMMON_INGREDIENTS = [
    'water', 'glycerin', 'niacinamide', 'vitamin c', 'vitamin e', 'salicylic acid', 'glycolic acid',
    'panthenol', 'alcohol', 'shea butter', 'cocamidopropyl betaine', 'tocopheryl acetate',
    'parfum', 'fragrance', 'citric acid', 'hyaluronic acid', 'allantoin', 'bisabolol',
    'benzophenone', 'phenoxyethanol', 'methylparaben', 'ethylparaben', 'geraniol',
    'alpha-isomethyl ionone', 'sodium chloride', 'castor oil', 'lotus flower', 'avocado',
    'beeswax', 'olive', 'sunflower', 'jojoba', 'retinol', 'ascorbic acid', 'ceramide',
    'zinc oxide', 'titanium dioxide', 'dimethicone', 'aloe', 'green tea', 'argan', 'quercetin',
    'homosalate', 'butyl methoxydibenzoylmethane', 'ethylhexyl salicylate', 'ethylhexyl triazone',
    'glycyrrhiza inflata root extract', 'coumarin', 'cyclomethicone', 'tapioca starch',
    'cetearyl alcohol', 'behenyl alcohol', 'methylpropanediol', 'glyceryl glucoside',
    'lauryl glucoside', 'peg-40 hydrogenated castor oil', 'peg-200 hydrogenated glyceryl palmate',
    'polyquaternium-10', 'propylene glycol', 'ci 42090', 'ci 16035', 'niacinamide', 'salicylic acid',
    'vitamin c', 'vitamin e', 'hyaluronic acid', 'panthenol', 'glycolic acid', 'retinol', 'ascorbic acid'
]

# Lowercase for matching
COMMON_INGREDIENTS = list(set([i.lower() for i in COMMON_INGREDIENTS]))

# Function to extract ingredients from description

def extract_ingredients(description):
    if pd.isna(description):
        return ''
    desc = description.lower()
    found = set()
    for ing in COMMON_INGREDIENTS:
        # Use word boundaries to avoid partial matches
        if re.search(r'\b' + re.escape(ing) + r'\b', desc):
            found.add(ing.title())
    # Try to extract after 'ingredients:' or 'ingredients included:'
    match = re.search(r'ingredients[\s:]*([a-z0-9,\-\s\./]+)', desc)
    if match:
        # Split by comma and clean
        extra = [i.strip().title() for i in match.group(1).split(',') if len(i.strip()) > 2]
        found.update(extra)
    return ', '.join(sorted(found))

# Apply extraction to each row
df['Ingredients'] = df.apply(lambda row: extract_ingredients(row['Product Description']), axis=1)

df.to_csv('skincare_products_with_ingredients.csv', index=False)

# Grouping products by shared ingredients
# Build a mapping from ingredient to product indices
ingredient_to_products = defaultdict(set)
for idx, row in df.iterrows():
    ings = [i.strip() for i in row['Ingredients'].split(',') if i.strip()]
    for ing in ings:
        ingredient_to_products[ing].add(idx)

# Find groups of products sharing at least 2 or 3 ingredients
min_shared = 2
product_groups = []
visited = set()
for i, row1 in df.iterrows():
    if i in visited:
        continue
    ings1 = set([x.strip() for x in row1['Ingredients'].split(',') if x.strip()])
    if not ings1:
        continue
    group = set([i])
    shared_ings = set()
    for j, row2 in df.iterrows():
        if i == j:
            continue
        ings2 = set([x.strip() for x in row2['Ingredients'].split(',') if x.strip()])
        common = ings1 & ings2
        if len(common) >= min_shared:
            group.add(j)
            shared_ings.update(common)
    if len(group) > 1:
        visited.update(group)
        product_names = [df.loc[x, 'Product Name'] for x in group]
        product_groups.append({
            'Shared Ingredients': ', '.join(sorted(shared_ings)),
            'Product Names': ', '.join(product_names)
        })

# Output grouped table to CSV
pd.DataFrame(product_groups).to_csv('ingredient_groups.csv', index=False)
print('Ingredient extraction and grouping complete. See skincare_products_with_ingredients.csv and ingredient_groups.csv.')
